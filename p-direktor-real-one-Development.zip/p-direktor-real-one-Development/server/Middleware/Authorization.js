const jwt = require("jsonwebtoken")
require("dotenv").config()

module.exports = async (req, res, next) => {
    try {
        const jwtToken = req.body.token;
        console.log(jwtToken)
            if (jwtToken === ""){
                res.status(403).json("you are not authorized")
            }
            const payload = jwt.verify(jwtToken, process.env.jwtSecret);
            req.user = payload.user;
            next();
    } catch (error) {
        console.log(error.message)
        res.status(403).send("you are not authorized")
    }
}
