const jwt = require("jsonwebtoken");
require("dotenv").config();

function jwtGeneratorPub(user_id) {
    const payload = {
        user: user_id
    }
    return jwt.sign(payload, "Social", {expiresIn: 3600})
}

module.exports = jwtGeneratorPub;