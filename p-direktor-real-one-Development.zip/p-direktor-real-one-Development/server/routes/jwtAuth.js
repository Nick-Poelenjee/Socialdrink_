const router = require("express").Router()
const pool = require("../db")
const bcrypt = require('bcrypt')
const jwtGenerator = require("../utils/jwtGenerator")
const jwtGeneratorPub = require("../utils/jwtGeneratorPub")
const validinfo=require("../Middleware/validinfo")
const authorization = require("../Middleware/authorization")



//register
router.post("/register",validinfo , async(req, res) => {
    try {
        //destructue the req.body (email, password)
        const { email, password, firstName, lastName } = req.body;

        //check if user exists if yes throw error
        const user = await pool.query("SELECT * from users Where email = $1",
        [email])

        if (user.rows.length ==! 0){
            res.status(401).send("User already exists")
        }
        
        //bcrypt password
        const saltRound = 10;
        const salt = await bcrypt.genSalt(saltRound);
        const encryptedPass = await bcrypt.hash(password, salt);

        //new user into DB get 
        const newUser = await pool.query(
            "INSERT INTO public.users(email, password) VALUES ($1, $2) RETURNING *",
            [email, encryptedPass] 
        )
         // create new user profile 
         const newUserProfile = await pool.query(
             "INSERT INTO public.userprofiles(user_id,org_id ,first_name, last_name) VALUES ($1, $2, $3, $4) RETURNING *",
             [newUser.rows[0].user_id,1 ,firstName, lastName]
         )


        //generate our jwt token
        const priToken = jwtGenerator(user.rows[0].user_id);       
        const pubToken = jwtGeneratorPub(user.rows[0].user_id)
        const userId =  user.rows[0].userId
        console.log(priToken)
        console.log(pubToken);
        res.json({priToken,pubToken,userId})
    } catch (error) {
        console.log(error.message)
        res.status(500)
    }
}
)

//login
router.post("/login",validinfo, async (req, res) => {
try {
    //destruct the req.body

    const { email, password } = req.body;

    
    //check if user exists if not throw error
    const user = await pool.query("SELECT * from users Where email = $1",
        [email])

        if (user.rows.length === 0){
            console.log("wrong pass")
            res.status(401).json("Email or password is incorrect")
        }

    //check if incoming password = DB password
        const validPassword = await bcrypt.compare(password, user.rows[0].password);
                if (!validPassword){
                    console.log("invalid pass")
            return  res.status(401).json("Email or password is incorrect")
        }
        
    //give them the jwt token
    
    const priToken = jwtGenerator(user.rows[0].user_id);       
    const pubToken = jwtGeneratorPub(user.rows[0].user_id)
    const userId =  user.rows[0].user_id
    console.log(user.rows[0].user_id);
    console.log(priToken)
    console.log(pubToken);
    console.log(userId)
    res.json({priToken,pubToken, userId})

} catch (error) {
    console.log(error.message)
    res.status(500)
}

}
)

//check jwt token
router.post("/validate-token", authorization, async (req, res) => {
    try {
        res.json(true);
    } catch (error) {
        console.log(error.message)
        res.status(500)
    }
}
)
module.exports = router

