const router = require("express").Router();
const pool = require("../db");
const authorization = require('../Middleware/authorization')

router.get("/1", authorization, async (req,res) => {
    try {
        console.log(res.user)
        const users = await pool.query(
        "SELECT * FROM users WHERE user_id = $1",
        [req.user]
        )
        res.json(users.rows[0])
    } catch (error) {
        console.log(error.message)
        res.status(500).json("server error")
    }
}
)

module.exports = router;
