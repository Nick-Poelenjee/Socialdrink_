const express = require("express");
const app = express();
const cors = require("cors");
const pool = require("./db");


//middleware
app.use(cors())
app.use(express.json())

const corsOptions = {
    origin: 'http://localhost:3000',
    optionsSuccessStatus: 200, // some legacy browsers (IE11, various SmartTVs) choke on 204

}

//Routes//

//dashboard route
app.use("/dashboard", require("./routes/dashboard"))

//register and login routes

app.use("/auth", cors(corsOptions), require("./routes/jwtAuth"))

//interest
//create interest
app.post("/interests", async (req, res) => {
    try {
        const { interest_name } = req.body;
        const newInterest = await pool.query(
            "INSERT INTO interests(interest_name) VALUES($1) RETURNING *",
            [interest_name])
        res.json(newInterest)
    } catch (error) {
        console.log(error.message)
    }
})
//link user to interest


//get all interests
app.get("/interests", async (req, res) => {
    try {
        const allTodos = await pool.query(
            "SELECT * FROM interests",
        )
        res.json(allTodos.rows)
    } catch (error) {
        console.log(error.message)
    }
})

app.post("/interestByName", async (req, res) => {
    try {
        console.log(req.body)
        const { interest_name } = req.body
        const Interests = await pool.query(
            "SELECT interest_id FROM interests WHERE interest_name = $1",
            [interest_name]
        )
        res.json(Interests.rows)
    } catch (error) {
        console.log(error.message)
    }
})

//get a interest
app.get("/interests/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const thisInterest = await pool.query(
            "SELECT * FROM interests WHERE interest_id = ($1)",
            [id]
        );

        res.json(thisInterest.rows)
    } catch (error) {
        console.log(error.message)
    }
})

//update a interest
app.put("/interests/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const { interest_name } = req.body;
        const updateInterest = await pool.query(
            "UPDATE interests SET interest_name = $1 WHERE interest_id = $2",
            [interest_name, id])
        res.json("todo was updated")
    } catch (error) {
        console.log(error.message)
    }
})

//delete a interest
app.delete("/interests/:id", async (req, res) => {
    try {
        const { id } = req.params
        const deleteInterest = await pool.query(
            "DELETE FROM interests where interest_id = $1",
            [id]
        )
        res.json("deleted the interest")
    } catch (error) {
        console.log(error.message)
    }
})

//users
//create user
app.post("/users", async (req, res) => {
    try {
        const { user_information } = req.body;
        console.log(req.body)
        console.log(user_information)
        const newUser = await pool.query(
            "INSERT INTO users(email_adress, password), VALUES($1) RETURNING *",
            [user_information])
        console.log(newUser)
        res.json(newUser)
    } catch (error) {
        console.log(error.message)
    }
})

//create user profile
app.listen(5000, () => {
    console.log("server started on port 5000")
})

// get profile by user ID
app.post("/email", async (req, res) => {
    console.log("123")
    try {
        const { id } = req.body;
        const userprofile = await pool.query(
            "SELECT  email FROM users where user_id = $1",
            [id])
        res.json(userprofile.rows);
    } catch (error) {
        console.log(error.message)
    }
})
//get name by user id
app.post("/name", async (req, res) => {
    console.log(1234)
    try {
        const { user_id } = req.body;
        const userprofile = await pool.query(
            "SELECT first_name, last_name FROM public.userprofiles where user_id = $1",
            [user_id])
        res.json(userprofile.rows);
    } catch (error) {
        console.log(error.message)
    }
})

// // get interest by user id 
app.post("/interestUser", async (req, res) => {
    try {
        const { id } = req.body;
        const userprofile = await pool.query(
            "SELECT public.interests.interest_id, interests.interest_name FROM public.user_interests LEFT JOIN public.interests on public.user_interests.interest_id = public.interests.interest_id where user_interests.user_id = $1",
            [id])
        res.json(userprofile.rows);
    } catch (error) {
        console.log(error.message)
    }
})

//update email
app.put("/email", async (req, res) => {
    try {
        const { email, user_id } = req.body;
        const updateEmail = await pool.query(
            "UPDATE public.users SET email= $1 WHERE user_id= $2 RETURNING email",
            [email, user_id]
        )
        res.json(updateEmail.rows)
    } catch (error) {
        console.log(error.message)
    }
})
app.put("/name", async (req, res) => {
    try {
        const { firstName, lastName, user_id } = req.body;
        const updateEmail = await pool.query(
            "UPDATE public.userprofiles SET first_name=$1, last_name=$2 WHERE user_id = $3;",
            [firstName, lastName, user_id]
        )
        res.json("name was updated to " + firstName + " " + lastName)
    } catch (error) {
        console.log(error.message)
    }
})

app.put("/available", async (req, res) => {
    try {
        const { morning, afternoon, evening, user_id } = req.body
        const updateAvailability = await pool.query(
            "UPDATE public.userprofiles SET morning=$1, afternoon=$2, evening=$3 WHERE user_id = $4",
            [morning, afternoon, evening, user_id]
        )
        res.json("availability was updated")
    } catch (error) {
        console.log(error.message)
    }
})
app.post("/available", async (req, res) => {
    try {
        const { user_id } = req.body
        const getAvailability = await pool.query(
            "SELECT morning, afternoon, evening  FROM public.userprofiles where user_id = $1",
            [user_id]
        )
        res.json(getAvailability)
    } catch (error) {
        console.log(error.message)
    }
})

//match user
app.post("/matchUsers", async (req, res) => {
    try {
        var sharedUser = []
        const { user_id, new_interests_id } = req.body
        console.log(req.body)
        //get current interests from user x from database
        const currentinterestId = await pool.query(
            "SELECT interest_id FROM user_interests where user_id = $1",
            [user_id]
        )

        //delete old interests
        const deleted = await pool.query(
            "DELETE From user_interests where user_id = $1 ",
            [user_id]
        )

        // add new interests
        for (let index = 0; index < new_interests_id.length; index++) {
            const newInterests = await pool.query(
                "INSERT INTO user_interests(interest_id, user_id)VALUES ($1, $2);",
                [new_interests_id[index], user_id]
            )
        }

        //get other users with similar interests
        for (let index = 0; index < new_interests_id.length; index++) {
            const sharedInterestUser = await pool.query(
                "SELECT DISTINCT user_id FROM user_interests WHERE interest_id = $1",
                [new_interests_id[index]]
            )
            sharedUser[index] = sharedInterestUser.rows
        }

        // get existing matches
        var existingMatches1 = await pool.query(
            "SELECT person2 FROM matches WHERE person1 = $1 ",
            [user_id]
        )
        var existingMatches2 = await pool.query(
            "SELECT person1 FROM matches WHERE person2 = $1 ",
            [user_id]
        )

        existingMatches2 = existingMatches2.rows
        existingMatches1 = existingMatches1.rows
        var existingMatches = []
        for (let i = 0; i < existingMatches1.length; i++) {
            existingMatches[i] = existingMatches1[i].person2
            console.log(existingMatches);
        }
        let j = 0
        for (let i = existingMatches.length; j < existingMatches2.length; i++) {
            existingMatches[i] = existingMatches2[j].person1
            console.log(existingMatches);
            j++
        }




        //check which users are available at the wished time
        var availableTimeUsers = []
        const availableTimes = await pool.query(
            "SELECT morning, afternoon, evening FROM public.userprofiles WHERE user_id = $1",
            [user_id]
        )
        const time = availableTimes.rows
        const morning = time[0].morning
        const afternoon = time[0].afternoon
        const evening = time[0].evening
        var availableTimeUsersMorning = [1]
        var availableTimeUsersAfternoon = [1]
        var availableTimeUsersEvening = [1]
        var availableMorning = []
        var availableAfternoon = []
        var availableEvening = []
        var availableUsers = []


        if (morning) {
            availableTimeUsersMorning = await pool.query(
                "SELECT user_id FROM userprofiles WHERE morning = true",
            )
            availableMorning = availableTimeUsersMorning.rows
            for (let i = 0; i < availableTimeUsersMorning.rows.length; i++) {
                availableUsers.push(availableMorning[i].user_id)
            }
        }
        if (afternoon) {
            availableTimeUsersAfternoon = await pool.query(
                "SELECT user_id FROM userprofiles WHERE morning = true",
            )
            availableAfternoon = availableTimeUsersAfternoon.rows
            for (let i = 0; i < availableTimeUsersMorning.rows.length; i++) {
                availableUsers.push(availableMorning[i].user_id)
            }
        }
        if (evening) {
            availableTimeUsersEvening = await pool.query(
                "SELECT user_id FROM userprofiles WHERE evening = true",
            )
            availableEvening = availableTimeUsersEvening.rows
            for (let i = 0; i < availableEvening.length; i++) {
                availableUsers.push(availableEvening[i].user_id)
            }
        }



        var matchableusers = []
        for (let i = 0; i < availableTimeUsersEvening.rows.length; i++) {
            matchableusers[i] = availableUsers[i]
        }
        console.log(matchableusers);

        var sharedUserId = []
        for (let i = 0; i < sharedUser.length; i++) {
            for (let j = 0; j < sharedUser[i].length; j++) {
                if (sharedUser[i][j].user_id !== user_id &&
                    matchableusers.includes(sharedUser[i][j].user_id) &&
                    !existingMatches.includes(sharedUser[i][j].user_id)) {
                    sharedUserId.push(sharedUser[i][j].user_id)
                }
            }
        }

        //how many similar interests do the other person have?
        function getMostFrequent(arr) {
            console.log(sharedUser.length)
            if (sharedUserId.length !== 0) {
                const hashmap = arr.reduce((acc, val) => {
                    acc[val] = (acc[val] || 0) + 1
                    return acc
                }, {})
                return Object.keys(hashmap).reduce((a, b) => hashmap[a] > hashmap[b] ? a : b)
            } else {
                res.json("no matches found")
            }
        }
        const matchedUser = getMostFrequent(sharedUserId)
        res.json(matchedUser)

        //put match in db
        if (matchedUser != null) {
            const match = await pool.query(
                "INSERT INTO matches (person1, person2) VALUES ($1, $2)",
                [user_id, matchedUser]
            )
        }
    } catch (error) {
        console.log(error.message)
    }
})
