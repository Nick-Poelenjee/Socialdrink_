import { useState } from 'react';
import './App.css';
import Menubar from './Components/Menubar/Menubar';
import Loginpage from './Components/Pages/Loginpage';
import RegistratiePage from './Components/Pages/RegistratiePage';
import Homepage from './Components/Pages/Homepage';
import React from 'react'
import Agenda from '../src/Components/Pages/Agenda';
import Contact from '../src/Components/Pages/Contact'
import Overons from '../src/Components/Pages/Overons'
import Profiel from '../src/Components/Pages/Profiel'
import {BrowserRouter as Router, Routes, Route, Redirect, useHistory} from 'react-router-dom'
import PlanJeGesprek from'../src/Components/Pages/PlanJeGesprek'
import Matchingpage from '../src/Components/Pages/Matchingpage';
import PageNotFound from './Components/Features/PageNotFound';
import RequireAuth from './RequireAuth';

const App = () => {
   //require auth is de private route block waarin de jwt wordt gecheckt
  return (
    <>
    <Routes>
             <Route path="/" element={<Loginpage/>} />
             <Route path="/Loginpage" element={<Loginpage/>} />
             <Route path="/Registreren" element={<RegistratiePage/>}/>
          <Route element={<RequireAuth/>}>
             <Route path="/PlanJeGesprek" element={<PlanJeGesprek />} />
             <Route path="/Home" element={<Homepage />} />
             <Route path="/Agenda" element={<Agenda />} />
             <Route path="/Contact" element={<Contact />} />
             <Route path="/Overons" element={<Overons/>} />
             <Route path="/Profiel" element={<Profiel/>} />
             <Route path='/MatchingPage' element={<Matchingpage/>}/>
            </Route>
             <Route path='/404PageNotFound' element={<PageNotFound/>}/>
             
        </Routes>
     </>


  );
}

export default App;
