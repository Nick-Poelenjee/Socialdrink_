import React, {
  useEffect,
  useState
} from 'react'
import {
  Navigate,
  Outlet,
  useLocation,
  useNavigate
} from 'react-router'
import Cookies from 'js-cookie'
import axios from 'axios'
const jwt = require("jsonwebtoken")

const RequireAuth = () => {
  //get token from cookies
  // create constant valid
  var valid = false

  //axios api request
  const axios = require('axios');
  const navigate = useNavigate();
  // const {
  //     state
  // } = useLocation();
  // const {
  //     page
  // } = state;
//   var [data, setData] = useState({
//       token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjozNSwiaWF0IjoxNjM5NDg0MDcwLCJleHAiOjE2Mzk0ODc2NzB9.so7rPZPpzAGVOifwHyoFhmzIWqfLeclG8Ohu5STGmAE"
//   })

      // if [] run only once

    //   data = JSON.stringify(data);
    //   console.log(data)

    //   //make request to the server to check token
    //   async function checkToken() {
    //       const config = {
    //           method: 'post',
    //           url: 'http://localhost:5000/auth/validate-token',
    //           headers: {
    //               'Content-Type': 'application/json',
    //           },
    //           data: data
    //       };
    //       //execute request with await so the rest of the functions waits for this to finish, if the token is valid make valid true
    //       await axios(config)
    //           .then(function(response) {
    //               console.log(response.data)
    //               if (JSON.stringify(response.data) === "true") {
    //                   console.log("good token, continue")
    //               }
    //               //if the token is not valid
    //               else {
    //                   console.log("invalid token")
    //               }
    //           })
    //           // if there is an error, return to the loginpage and log the error in the console
    //           .catch(function(error) {
    //               console.log(error);

    //           });


    // const jwttoken = Cookies.get('token')
  
    // console.log(valid)
    // }

     

      //
    //   checkToken()
   try {
    const jwttoken = Cookies.get('pubToken')
    console.log(jwttoken)
    const test = jwt.verify(jwttoken, "Social")
    console.log(test)
  } catch (error) {
      console.log(error.message);
      return navigate("/")
  }


  if ("" === "") {
      console.log("go on then")
      return ( < Outlet / > )
  } else {
    console.log("but how")
}
}

export default RequireAuth 