const FontLink = () => {
    return(
        <div className="card">
            <span className="font-link">
                This is with Font Link. We are linking the fonts from the Google Fonts.
            </span>
        </div>
    )
  };
  
  export default FontLink;