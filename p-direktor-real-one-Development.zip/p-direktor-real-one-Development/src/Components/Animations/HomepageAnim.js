import lottie from 'lottie-web';
import React, { Suspense, useEffect, useRef } from 'react';


export default function HomepageAnim() {
const container = useRef(null)

  useEffect(() => {
    lottie.loadAnimation({
      container: container.current,
      renderer: 'svg',
      loop: true,
      autoplay: false,
      animationData: require('../images/HomepageAnim.json')
    })
  }, [])

  return(
    <div 
        className="HomepageAnimcontainer" ref={container}   
        onMouseEnter={() => lottie.play()}
        onMouseLeave={() => lottie.pause()}>

  </div>
)
}