import lottie from 'lottie-web';
import React, { Suspense, useEffect, useRef } from 'react';


export default function PNFAnim() {
const container = useRef(null)

  useEffect(() => {
    lottie.loadAnimation({
      container: container.current,
      renderer: 'svg',
      loop: true,
      autoplay: true,
      animationData: require('../images/PNFAnim.json')
    })
  }, [])

  return(
    <div
        className="PNFAnimcontainer" ref={container}> 
  </div>
)
}