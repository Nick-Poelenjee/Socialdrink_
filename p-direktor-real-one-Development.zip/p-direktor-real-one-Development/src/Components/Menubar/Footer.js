const Footer = () => {
    return (
        <div className="Footer">
            <nav>
                <ul>
                    <li>
                        <a href='/Contact'>Contact</a>
                    </li>
                </ul>
            </nav>

        </div>
    )
}

export default Footer
