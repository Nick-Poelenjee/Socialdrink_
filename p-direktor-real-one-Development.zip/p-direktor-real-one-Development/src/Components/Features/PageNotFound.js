import React from 'react'
import PNFAnim from '../Animations/PNFAnim'

const PageNotFound = () => {
    return (
        <div className='PageNotFound'>

            <PNFAnim />
            
        </div>
    )
}

export default PageNotFound
