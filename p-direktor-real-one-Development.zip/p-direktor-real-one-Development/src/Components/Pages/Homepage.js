import React from 'react'
import logo from '../images/logo_horizontal_final.png'
import {BrowserRouter as Router,Link, NavLink} from 'react-router-dom'
import Footer from '../Menubar/Footer'
import Menubar from '../Menubar/Menubar'
import HomepageAnim from '../Animations/HomepageAnim'



export default function Homepage() {
    return (
        <>
    <div className="App">

        <div className='headerContainer'>

        <meta name="viewport" content="width=device-width, initial-scale=1.0"></meta>

        <NavLink to='/Home' ><img src={logo} height='100px' width='400px' alt= 'main logo'/> </NavLink>

        <Menubar />
        
        </div>
        
            <div className="rectangle">
                
                    <div className='mainText'>Ontmoet en inspireer je collega's onder het genot van een drankje!
                    
                    <Link to="/Planjegesprek">
                        <button 
                        className='PlanGesprekButton'> <span>Plan je gesprek</span>
                        </button>
                    </Link>
                    </div>
            
            <div className="homepageImage"><HomepageAnim/></div>
        
        </div>
        <div className='Footer'><Footer /></div>
    </div>
    </>
    )
}
