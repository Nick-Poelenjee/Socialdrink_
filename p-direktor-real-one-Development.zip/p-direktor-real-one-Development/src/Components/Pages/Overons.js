import logo from '../images/logo_horizontal_final.png'
import React from 'react'
import Footer from '../Menubar/Footer'
import Menubar from '../Menubar/Menubar'
import corona from '../images/corona_atom.png'
import gesprek from '../images/gesprek.jpg'
import online_gesprek from '../images/online_gesprek.jpg'
import superteam from '../images/superteam.jpg'
import { NavLink } from 'react-router-dom'

const Overons = () => {
    return (
        <>

        <div className='App'>

        <div className='headerContainer'>
        
        <NavLink to='/Home' ><img src={logo} height='100px' width='400px' alt= 'main logo'/> </NavLink>

        <Menubar/>

        </div>
            
            <div className = "rectangleOverOns">
                
                <div className='overons_box'>
                    
                    <div className = "informatie_overons_1">
                        <div className='overOnsText1'>
                            <h3 className='overons_titel'>Probleem</h3>
                            Door het Corona-virus wordt het thuiswerken enorm gestimuleerd. Dat klinkt voor velen als muziek in de oren
                            maar er is een ook nadeel die een groot gedeelte van de werknemers kan beïnvloeden in de loop der tijd.
                        </div>

                        <div className="informatie_overons_1_foto">
                        <img src={corona} height='auto' width='300px' margin='20px'/>
                        </div>
                    </div>
                </div>

                <div className='overons_box'>
                    <div className = "informatie_overons_2">
                        <div className="informatie_overons_2_foto">
                        <img src={gesprek} height="300px" width="450px"/>
                        </div>

                        <div className='overOnsText2'>
                        <h3 className='overons_titel'>Contact</h3>
                            Het klinkt heerlijk om vanuit huis te werken, in velen gevallen is dat zeker ook het geval, maar wat nou als het contact met je collega's
                            en je andere medemensen achteruit gaat? Heel veel collega's hebben niet meer een spontane koffiepraat bij het koffiezet apparaat, omdat er bijna geen mensen zijn op kantoor.
                            Dit maakt het netwerken meteen een stuk lastiger.
                        </div>
                    </div>
                </div>

                <div className='overons_box'>
                    <div className = "informatie_overons_3">
                        <div className='overOnsText3'>
                        <h3 className='overons_titel'>Oplossing</h3>
                            Voor dege die interesse hebben om te netwerken en nieuwe mensen te ontmoeten binnen of buiten je eigen sector, is SocialDrink misschien wel wat voor jou.
                            SocialDrink is een bedrijf die met als doel is ontstaan om het contact tussen de werknemers van de rijksoverheid te verbeteren.
                            Uit onderzoek blijkt dat het contact tussen de werknemers rijksoverheid, tijdens de coronatijd, een stuk achteruit is gegaan.
                        </div>
                        
                        <div className="informatie_overons_3_foto">
                            <img src={online_gesprek} height="300px" width="450px"/>
                        </div>
                </div>
                </div>

                <div className='overons_box'>
                <div className = "informatie_overons_4">
                <div className="informatie_overons_4_foto">
                    <img src={superteam} height="300px" width="450px"/>
                </div>

                <div className='overOnsText4'>
                  <h3 className='overons_titel'>Team</h3>
                   Wij zijn een groep gemotiveerde studenten die namens de rijksoverheid een oplossing hebben bedacht en uitgevoerd voor het hierboven genoemde probleem.
                   </div>

                </div>
                </div>

            </div>
        <Footer/>

        </div>
        </>
    )
}

export default Overons

