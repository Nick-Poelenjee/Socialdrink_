import logo from '../images/logo_horizontal_final.png'
import Footer from '../Menubar/Footer'
import telefoon from "../images/telephone-vector-icon-28.png"
import email from "../images/email-vector.png"
import Menubar from '../Menubar/Menubar'
import { NavLink } from 'react-router-dom'

const Contact = () => {
    return (
    <>
<div className='App'>
    
    <div className='headerContainer'>
        
        <NavLink to='/Home' ><img src={logo} height='100px' width='400px' alt= 'main logo'/> </NavLink>

        <Menubar />
    </div>
        <div className="rectangleContact">

            <div className='viewheightcontainer'>

                <div className="mainTextContact">Voor mogelijke problemen en/of vragen voel je vrij om contact op te nemen met het SocialDrink Development team</div>
                    
                
                <div className="imagesContainerContact">
                    <img className="telefoonVector" src={telefoon} height="200px" width="200px" alt= "Telefoon vector" />
                    <img className="emailVector" src={email} height="200px" width="200px" alt="email vector" />
                </div>
                
                <div className="textContainerContact">
                    <div>06-12345678</div>
                    <div>SocialDrink@info.nl</div>
                </div>
            </div>

            
        </div>
    <Footer />
</div>
    </>
    )
}

export default Contact
