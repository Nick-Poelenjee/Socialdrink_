import { Fragment, useState } from "react"
import {BrowserRouter as Router, Routes, Link} from 'react-router-dom'
import Cookies from "js-cookie";
import { NavigationType, Outlet, useNavigate } from "react-router";
import logo from '../images/logo_horizontal_final.png'
import Homepage from "./Homepage";
 
function Loginpage() {
    let navigate = useNavigate();

    function nav(){
        console.log(34567)
        navigate("/Home", {page: "/Home"})
    }

    const axios = require('axios');


     const onSubmitForm1 = async(e) => {
        try {
            console.log(0)
            await onSubmitForm()
            nav()
        } catch (error) {
            console.log(error.message)
        }
        
    }
    //create usestate for the inputs
    const [inputs, setInputs] = useState({
            email : "",
            password: ""
    })
    const {email, password} = inputs; 
    // make it possible to change the inouts
    const onChange = e => {
         setInputs({...inputs, [e.target.name] : e.target.value})
    }
    //form submit verwerken
    const onSubmitForm = async(e) => {
        //  e.preventDefault();
        try {
const data = JSON.stringify({
    email, password
});
console.log(data)

//axios request aanmaken
const loginRequest = {
  method: 'post',
  url: 'http://localhost:5000/auth/login',
  headers: { 
    'Content-Type': 'application/json'
  },
  data : data
};
// set cookies
await axios(loginRequest)
.then(function (response) {
    console.log(69)
    const priToken = response.data.priToken
    const pubToken = response.data.pubToken
    const user_id  = response.data.userId
    Cookies.set('priToken', priToken)   
    Cookies.set('pubToken', pubToken)  
    Cookies.set('user_id', user_id)
    console.log(pubToken)
    console.log(priToken)
    console.log(4)

}  
    );            

        } catch (error) {
                console.log(error.message)
            }

            }
            
            //hieronder bij link to=/home is de link te vroeg en is onsubmit form nog niet uitgevoerd
            //login is admin@admin.com met als wachtwoord admin
    return (
        <div className='loginContainer'>

            <img src={logo} height='180px' width='700px' alt= 'main logo'/>

        <form>
            <div className = "form-inner">
                <h2>Login</h2>
                <div className= "form-group">
                    <label htmlFor="email">E-mail: </label>
                    <input 
                    type="email" 
                    name="email" 
                    id="email" 
                    placeholder = "email " 
                    value={email} 
                    onChange={e => onChange(e)}/>
                </div>

                <div className= "form-group">
                    <label htmlFor="password">Wachtwoord:</label>
                    <input 
                    type="password" 
                    name="password" 
                    id="password" 
                    placeholder = "password"
                    value={password} 
                    onChange={e => onChange(e)}/>
                </div> 
                
                <Link to="/">
                <button className="loginbutton" onClick={onSubmitForm1}>
                    LOGIN
                </button>
                </Link>

               <Link to="/Registreren">
                <div className= "registreren">Registreer hier</div>
                </Link>
                
                <div className= "wachtwoord">Wachtwoord vergeten</div>
            

 
            </div>
        </form>
        </div>
)
}

export default Loginpage


