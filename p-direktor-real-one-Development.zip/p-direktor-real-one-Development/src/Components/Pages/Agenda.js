import Footer from "../Menubar/Footer"
import Menubar from "../Menubar/Menubar"
import { NavLink } from "react-router-dom"
import logo from '../images/logo_horizontal_final.png'

const Agenda = () => {
    return (
<>
<div className="App">

    <div className='headerContainer'>

        <meta name="viewport" content="width=device-width, initial-scale=1.0"></meta>

        <NavLink to='/Home' ><img src={logo} height='100px' width='400px' alt= 'main logo'/> </NavLink>

    <Menubar />

    </div>
        <div className='rectangleAgenda'>
            
            <div className='agendaText'> Wordt aan gewerkt! </div>
        
        </div>
    <Footer/>
</div>
</>
    )
}

export default Agenda
